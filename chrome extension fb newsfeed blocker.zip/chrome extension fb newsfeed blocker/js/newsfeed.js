	var element = document.getElementById("contentArea");
	element.parentNode.removeChild(element);